package com.github.rccookie.engine2d.impl.greenfoot;

import java.util.HashSet;
import java.util.Set;

import com.github.rccookie.engine2d.impl.InputAdapter;
import com.github.rccookie.engine2d.impl.MouseData;
import com.github.rccookie.event.BiParamEvent;
import com.github.rccookie.event.ParamEvent;
import com.github.rccookie.event.SimpleBiParamEvent;
import com.github.rccookie.event.SimpleParamEvent;
import com.github.rccookie.event.action.BiParamAction;
import com.github.rccookie.event.action.ParamAction;
import com.github.rccookie.geometry.performance.int2;
import greenfoot.Greenfoot;
import greenfoot.MouseInfo;

enum GreenfootInputAdapter implements InputAdapter {

    INSTANCE;

    private static final String[] KEYS = {
            "escape",
            "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12",
            // "^", "&acute;", // Not supported because Greenfoot currently does not report key release for these keys: (^,`)
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
            "\u00DF", "\u00E4", "\u00F6", "\u00FC", // ß, ä, ö, ü
            "backspace", "insert", "delete", "home", "end", "page up", "page down",
            "+", "-", "*", "/","<",
            "tab", "shift", "control", "alt", "space", "enter",
            "left", "right", "up", "down",
            ".", ",", "#",
            "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
            "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"
    };

    private final Set<String> pressed = new HashSet<>();
    private final BiParamEvent<String, Boolean> keyEvents = new SimpleBiParamEvent<>();
    private final ParamEvent<MouseData> mouseEvents = new SimpleParamEvent<>();

    @Override
    public void attachKeyEvent(BiParamAction<String, Boolean> event) {
        keyEvents.add(event);
    }

    @Override
    public void attachMouseEvent(ParamAction<MouseData> event) {
        mouseEvents.add(event);
    }

    @Override
    public int2 getMousePos() {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        return new int2(mouse.getX(), mouse.getY());
    }

    @Override
    public boolean isKeyDataAvailable() {
        return true;
    }

    @Override
    public boolean isMouseDataAvailable() {
        return Greenfoot.getMouseInfo() != null;
    }

    void update() {
        for(String key : KEYS) {
            if(Greenfoot.isKeyDown(key)) {
                if(!pressed.contains(key)) {
                    pressed.add(key);
                    keyEvents.invoke(toValidName(key), true);
                }
            }
            else if(pressed.contains(key)) {
                pressed.remove(key);
                keyEvents.invoke(toValidName(key), false);
            }
        }

        if(Greenfoot.mousePressed(null))
            mouseEvents.invoke(getMouseData(true));
        if(Greenfoot.mouseClicked(null))
            mouseEvents.invoke(getMouseData(false));
    }

    private static MouseData getMouseData(boolean includeButton) {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        return new MouseData(new int2(mouse.getX(), mouse.getY()), includeButton ? mouse.getButton() : 0);
    }

    private static String toValidName(String key) {
        switch(key) {
            case "escape":    return "esc";
            case "control":   return "ctrl";
            case "space":     return " ";
            case "page up":   return "pageup";
            case "page down": return "pagedown";
            default:          return key;
        }
    }
}
