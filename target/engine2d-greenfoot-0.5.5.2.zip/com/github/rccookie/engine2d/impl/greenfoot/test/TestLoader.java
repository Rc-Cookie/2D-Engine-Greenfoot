package com.github.rccookie.engine2d.impl.greenfoot.test;

import com.github.rccookie.engine2d.impl.greenfoot.GreenfootApplicationLoader;
import com.github.rccookie.engine2d.impl.greenfoot.GreenfootStartupPrefs;
import com.github.rccookie.engine2d.impl.greenfoot.Session;
import com.github.rccookie.geometry.performance.int2;

public class TestLoader extends GreenfootApplicationLoader {

    public TestLoader() {
        super(new TestInitializer(), new GreenfootStartupPrefs(new int2(800, 600), Session.ONLINE));
    }
}
