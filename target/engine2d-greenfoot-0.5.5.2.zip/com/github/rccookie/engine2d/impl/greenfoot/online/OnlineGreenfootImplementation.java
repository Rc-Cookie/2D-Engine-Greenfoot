package com.github.rccookie.engine2d.impl.greenfoot.online;

import com.github.rccookie.engine2d.impl.ImageImplFactory;
import com.github.rccookie.engine2d.impl.OnlineManager;
import com.github.rccookie.engine2d.impl.greenfoot.GreenfootImplementation;
import com.github.rccookie.engine2d.util.Coroutine;
import com.github.rccookie.engine2d.util.Future;

import org.teavm.jso.JSBody;

public class OnlineGreenfootImplementation extends GreenfootImplementation {

    @Override
    public ImageImplFactory getImageFactory() {
        return OnlineGreenfootImageImplFactory.INSTANCE;
    }

    @Override
    public OnlineManager getOnlineManager() {
        return OnlineGreenfootOnlineManager.INSTANCE;
    }

    @Override
    public boolean supportsMultithreading() {
        return false;
    }

    @Override
    public boolean supportsNativeIO() {
        return false;
    }

    @Override
    public boolean supportsAWT() {
        return false;
    }

    @Override
    public boolean supportsSleeping() {
        return false;
    }

    @Override
    public void sleep(long millis, int nanos) {
        // Only used if supportsSleeping is false
        long targetTime = System.nanoTime() + (millis * 1000000) + nanos;
        //noinspection StatementWithEmptyBody
        while(System.nanoTime() < targetTime);
    }

    @Override
    public void yield() {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> Future<T> startCoroutine(Coroutine<T> coroutine) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void sleepUntilNextFrame() {
        throw new UnsupportedOperationException();
    }

    @JSBody(script = "")
    private static native void yield0();
}
