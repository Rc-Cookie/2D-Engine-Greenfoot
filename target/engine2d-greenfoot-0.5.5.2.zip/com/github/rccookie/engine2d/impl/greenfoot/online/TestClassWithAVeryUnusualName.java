package com.github.rccookie.engine2d.impl.greenfoot.online;

public class TestClassWithAVeryUnusualName {
}
