package com.github.rccookie.engine2d.impl.greenfoot.online;

import com.github.rccookie.engine2d.Color;
import com.github.rccookie.engine2d.Image;
import com.github.rccookie.engine2d.impl.ImageImpl;
import com.github.rccookie.engine2d.impl.greenfoot.GreenfootImageImpl;
import com.github.rccookie.geometry.performance.int2;
import greenfoot.GreenfootImage;
import org.jetbrains.annotations.NotNull;

class OnlineGreenfootImageImpl extends GreenfootImageImpl {

    Color currentColor = null;

    OnlineGreenfootImageImpl(GreenfootImage image) {
        super(image);
    }

    OnlineGreenfootImageImpl(int2 size) {
        super(size);
    }

    OnlineGreenfootImageImpl(String file) {
        super(file);
    }

    @Override
    @NotNull
    public ImageImpl clone() {
        return new OnlineGreenfootImageImpl(new GreenfootImage(image));
    }

    @Override
    public void fillRect(int2 topLeft, int2 size, Color color) {
        updateColor(color);
        image.fillRect(topLeft.x, topLeft.y, size.x, size.y);
    }

    @Override
    public void drawRect(int2 topLeft, int2 size, Color color) {
        updateColor(color);
        image.drawRect(topLeft.x, topLeft.y, size.x - 1, size.y - 1);
    }

    @Override
    public void fillOval(int2 center, int2 size, Color color) {
        updateColor(color);
        image.fillOval(center.x - size.x / 2, center.y - size.y / 2, size.x, size.y);
    }

    @Override
    public void drawOval(int2 center, int2 size, Color color) {
        updateColor(color);
        image.drawOval(center.x - size.x / 2, center.y - size.y / 2, size.x, size.y);
    }

    @Override
    public void drawLine(int2 from, int2 to, Color color) {
        updateColor(color);
        image.drawLine(from.x, from.y, to.x, to.y);
    }

    @Override
    public ImageImpl scaled(int2 newSize, Image.AntialiasingMode aaMode) {
        // No way of changing antialiasing mode here...
        GreenfootImage scaled = new GreenfootImage(image);
        scaled.scale(newSize.x, newSize.y);
        return new OnlineGreenfootImageImpl(scaled);
    }


    private void updateColor(Color color) {
        if(currentColor == color) return;
        currentColor = color;
        image.setColor(toGreenfootColor(color));
    }
}
