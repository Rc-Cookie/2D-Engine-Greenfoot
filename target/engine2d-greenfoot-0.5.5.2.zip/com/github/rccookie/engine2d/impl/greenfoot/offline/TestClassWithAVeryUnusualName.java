package com.github.rccookie.engine2d.impl.greenfoot.offline;

public class TestClassWithAVeryUnusualName {


}
