package com.github.rccookie.engine2d.impl.greenfoot;

import java.io.PrintWriter;
import java.io.StringWriter;

import com.github.rccookie.engine2d.Application;
import com.github.rccookie.engine2d.impl.ApplicationLoader;
import com.github.rccookie.engine2d.impl.ILoader;
import com.github.rccookie.engine2d.impl.greenfoot.offline.OfflineGreenfootImplementation;
import com.github.rccookie.engine2d.impl.greenfoot.online.OnlineGreenfootImplementation;
import com.github.rccookie.util.Arguments;

import greenfoot.Color;
import greenfoot.Greenfoot;
import greenfoot.GreenfootImage;
import greenfoot.World;
import greenfoot.export.GreenfootScenarioApplication;

public abstract class GreenfootApplicationLoader extends World implements ApplicationLoader {

    private boolean firstFrame = true;

    private final ILoader initializer;
    public GreenfootApplicationLoader(ILoader initializer, GreenfootStartupPrefs prefs) {
        super(prefs.startupSize.x, prefs.startupSize.y, 1);

        this.initializer = Arguments.checkNull(initializer);

        Session.calcCurrent(prefs); // Also configures console settings

        initializer.initialize();

        Greenfoot.setSpeed(100);
        Greenfoot.start();
    }

    protected String getLoadingString() {
        return "Loading...";
    }


    @Override
    public void act() {
        if(firstFrame) {
            firstFrame = false;
            try {
                GreenfootImage text = new GreenfootImage(getLoadingString(), 20, Color.DARK_GRAY, new Color(0,0,0,0));
                getBackground().drawImage(text, 0, 0);
                repaint();

                // TODO: Check if application is already setup (reset was pressed) and delete all maps and cameras instead

                Application.setup(Session.current() == Session.ONLINE ? new OnlineGreenfootImplementation() : new OfflineGreenfootImplementation());

                initializer.load();

                // Do greenfoot setup again after initialize() to override any user settings
                Greenfoot.setSpeed(100);
                Greenfoot.start();
                Application.start();
            } catch(Exception e) {
                System.err.println("An exception occurred during the initialization of the application:");
                e.printStackTrace();

                String message = e.toString();
                try {
                    StringWriter writer = new StringWriter();
                    e.printStackTrace(new PrintWriter(writer));
                    message = writer.toString();
                } catch(Exception f) {
                    message += "\nFailed to print stack trace:\n" + f;
                }
                GreenfootImage background = getBackground();
                background.setColor(Color.DARK_GRAY);
                background.fill();
                GreenfootImage text = new GreenfootImage(message, 20, Color.RED, new Color(0,0,0,0));
                background.drawImage(text, (background.getWidth() - text.getWidth()) / 2, 0);
            }
        }
        Greenfoot.setWorld(GreenfootDisplay.INSTANCE.world);
    }



    public static void main(String[] args) {
        javafx.application.Application.launch(GreenfootScenarioApplication.class, args);
    }
}
